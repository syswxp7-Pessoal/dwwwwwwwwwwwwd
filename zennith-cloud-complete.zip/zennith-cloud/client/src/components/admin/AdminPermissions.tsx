import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Loader2 } from "lucide-react";

export default function AdminPermissions() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const addAdminMutation = trpc.admin.addAdmin.useMutation({
    onSuccess: () => {
      toast.success("Admin adicionado com sucesso!");
      setEmail("");
      setPassword("");
      setIsOpen(false);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao adicionar admin");
    },
  });

  const handleAddAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await addAdminMutation.mutateAsync({
        email,
        password,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Gerenciar Permissões</CardTitle>
            <CardDescription>
              Adicione novos usuários admin e configure suas permissões
            </CardDescription>
          </div>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Usuário
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Novo Admin</DialogTitle>
                <DialogDescription>
                  Crie um novo usuário administrador com permissões básicas
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleAddAdmin} className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="admin-email" className="text-sm font-medium">
                    Email
                  </label>
                  <Input
                    id="admin-email"
                    type="email"
                    placeholder="admin@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={isLoading}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="admin-password" className="text-sm font-medium">
                    Senha
                  </label>
                  <Input
                    id="admin-password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    required
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-lg space-y-3">
                  <p className="text-sm font-medium text-slate-900">Permissões Iniciais:</p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Checkbox id="view-stats" defaultChecked disabled />
                      <label htmlFor="view-stats" className="text-sm cursor-pointer">
                        Ver Estatísticas
                      </label>
                    </div>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading || !email || !password}>
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Adicionando...
                    </>
                  ) : (
                    "Adicionar Admin"
                  )}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600">
            Apenas o proprietário (crispravato746@gmail.com) pode gerenciar permissões de outros admins.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
