import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Loader2 } from "lucide-react";

export default function AdminStatistics() {
  const { data: stats, isLoading } = trpc.admin.getStatistics.useQuery();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
      </div>
    );
  }

  if (!stats) {
    return <div className="text-center text-slate-600">Erro ao carregar estatísticas</div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Total de Usuários
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">
              {stats.totalUsers}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-slate-600">
              Total de Aplicações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-slate-900">
              {stats.totalApplications}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Languages Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Linguagens Mais Usadas</CardTitle>
          <CardDescription>
            Top 5 linguagens de programação utilizadas
          </CardDescription>
        </CardHeader>
        <CardContent>
          {stats.topLanguages.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats.topLanguages}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="language" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-center text-slate-600 py-8">
              Nenhuma estatística disponível
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
