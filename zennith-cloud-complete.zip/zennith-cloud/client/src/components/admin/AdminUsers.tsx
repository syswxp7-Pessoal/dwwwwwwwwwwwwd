import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Search, Edit2, Loader2, Copy, Eye, EyeOff } from "lucide-react";

export default function AdminUsers() {
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [ramMb, setRamMb] = useState("");
  const [vcpu, setVcpu] = useState("");

  const { data: users, isLoading } = trpc.admin.listUsers.useQuery({ search });
  const updateResourcesMutation = trpc.admin.updateUserResources.useMutation({
    onSuccess: () => {
      toast.success("Recursos atualizados com sucesso!");
      setIsEditOpen(false);
      setSelectedUser(null);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar recursos");
    },
  });

  const handleEditUser = (user: any) => {
    setSelectedUser(user);
    setRamMb(user.totalRamMb.toString());
    setVcpu(user.totalVcpu.toString());
    setIsEditOpen(true);
  };

  const handleSaveResources = async () => {
    if (!selectedUser) return;

    try {
      await updateResourcesMutation.mutateAsync({
        userId: selectedUser.id,
        totalRamMb: ramMb ? parseInt(ramMb) : undefined,
        totalVcpu: vcpu ? parseInt(vcpu) : undefined,
      });
    } catch (error) {
      console.error("Error updating resources:", error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search */}
      <Card>
        <CardHeader>
          <CardTitle>Pesquisar Usuários</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Pesquisar por email..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <Card>
        <CardHeader>
          <CardTitle>Usuários Cadastrados</CardTitle>
          <CardDescription>
            Total: {users?.length || 0} usuários
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
            </div>
          ) : users && users.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-slate-200 bg-slate-50">
                  <tr>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Email</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Senha</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Nome</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">RAM</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">vCPU</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-700">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user: any) => (
                    <tr key={user.id} className="border-b border-slate-100 hover:bg-slate-50">
                      <td className="py-3 px-4">{user.email}</td>
                      <td className="py-3 px-4">
                        <code className="bg-slate-100 px-2 py-1 rounded text-xs font-mono">
                          {user.password || "-"}
                        </code>
                      </td>
                      <td className="py-3 px-4">{user.name || "-"}</td>
                      <td className="py-3 px-4">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">
                          {user.totalRamMb}MB / {user.usedRamMb}MB
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">
                          {user.totalVcpu} / {user.usedVcpu}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEditUser(user)}
                        >
                          <Edit2 className="w-4 h-4 mr-2" />
                          Editar
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center text-slate-600 py-8">
              Nenhum usuário encontrado
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Recursos do Usuário</DialogTitle>
            <DialogDescription>
              {selectedUser?.email}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">RAM Total (MB)</label>
              <Input
                type="number"
                value={ramMb}
                onChange={(e) => setRamMb(e.target.value)}
                min="256"
                step="256"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">vCPU Total</label>
              <Input
                type="number"
                value={vcpu}
                onChange={(e) => setVcpu(e.target.value)}
                min="1"
                step="1"
              />
            </div>
            <Button
              onClick={handleSaveResources}
              disabled={updateResourcesMutation.isPending}
              className="w-full"
            >
              {updateResourcesMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Salvando...
                </>
              ) : (
                "Salvar Alterações"
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
