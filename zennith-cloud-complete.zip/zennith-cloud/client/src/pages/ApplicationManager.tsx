import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  Loader2,
  Play,
  Pause,
  RotateCcw,
  Copy,
  Trash2,
  ChevronRight,
  File,
  Folder,
} from "lucide-react";

interface RouteParams {
  appId: string;
}

export default function ApplicationManager() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [appId, setAppId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState("projeto");

  // Parse appId from URL
  useEffect(() => {
    const match = window.location.pathname.match(/\/app\/(\d+)/);
    if (match) {
      setAppId(parseInt(match[1]));
    }
  }, []);

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading || !appId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-accent mx-auto mb-4" />
          <p className="text-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLocation("/dashboard")}
              className="text-muted-foreground hover:text-foreground"
            >
              ← Voltar
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">Z</span>
              </div>
              <span className="text-xl font-bold text-foreground glow-neon">Zennith Cloud</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <ApplicationTabs appId={appId} />
      </main>
    </div>
  );
}

function ApplicationTabs({ appId }: { appId: number }) {
  const { data: app } = trpc.applications.get.useQuery({ appId });
  const { data: logs } = trpc.applications.getLogs.useQuery({ appId }, { refetchInterval: 1000 });
  const { data: fileStructure } = trpc.applications.getFileStructure.useQuery({ appId });
  
  useEffect(() => {
    console.log('[ApplicationTabs] fileStructure:', fileStructure);
  }, [fileStructure]);

  return (
    <div className="space-y-6">
      {/* App Info */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{app?.name}</h1>
          <p className="text-muted-foreground mt-1">{app?.description}</p>
        </div>
        <div
          className={`px-4 py-2 rounded-full text-sm font-semibold ${
            app?.status === "running"
              ? "bg-green-500/20 text-green-400"
              : app?.status === "error"
                ? "bg-red-500/20 text-red-400"
                : "bg-muted text-muted-foreground"
          }`}
        >
          {app?.status === "running" ? "Ativo" : app?.status === "error" ? "Erro" : "Parado"}
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="projeto" className="w-full">
        <TabsList className="bg-card border-b border-border/50 rounded-none">
          <TabsTrigger value="projeto" className="rounded-none">
            Projeto
          </TabsTrigger>
          <TabsTrigger value="arquivos" className="rounded-none">
            Arquivos
          </TabsTrigger>
          <TabsTrigger value="configuracoes" className="rounded-none">
            Configurações
          </TabsTrigger>
        </TabsList>

        {/* Projeto Tab */}
        <TabsContent value="projeto" className="space-y-6">
          <ProjetoTab appId={appId} app={app} logs={logs} />
        </TabsContent>

        {/* Arquivos Tab */}
        <TabsContent value="arquivos" className="space-y-6">
          <ArquivosTab fileStructure={fileStructure} />
        </TabsContent>

        {/* Configurações Tab */}
        <TabsContent value="configuracoes" className="space-y-6">
          <ConfiguracoesTab appId={appId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ProjetoTab({
  appId,
  app,
  logs,
}: {
  appId: number;
  app: any;
  logs: any;
}) {
  const startMutation = trpc.applications.start.useMutation({
    onSuccess: () => {
      toast.success("Aplicação iniciada!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao iniciar");
    },
  });

  const stopMutation = trpc.applications.stop.useMutation({
    onSuccess: () => {
      toast.success("Aplicação parada!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao parar");
    },
  });

  const restartMutation = trpc.applications.restart.useMutation({
    onSuccess: () => {
      toast.success("Aplicação reiniciada!");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao reiniciar");
    },
  });

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="bg-card border-border/50 p-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Controles</h3>
          <div className="flex gap-3 flex-wrap">
            <Button
              onClick={() => startMutation.mutate({ appId })}
              disabled={app?.status === "running" || startMutation.isPending}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {startMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Ligando...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Ligar
                </>
              )}
            </Button>
            <Button
              onClick={() => stopMutation.mutate({ appId })}
              disabled={app?.status !== "running" || stopMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {stopMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Parando...
                </>
              ) : (
                <>
                  <Pause className="w-4 h-4 mr-2" />
                  Parar
                </>
              )}
            </Button>
            <Button
              onClick={() => restartMutation.mutate({ appId })}
              disabled={app?.status !== "running" || restartMutation.isPending}
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              {restartMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Reiniciando...
                </>
              ) : (
                <>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reiniciar
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>

      {/* App Info */}
      <Card className="bg-card border-border/50 p-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Informações</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Arquivo Principal</p>
              <p className="text-foreground font-mono">{app?.entryPoint}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">RAM Alocada</p>
              <p className="text-foreground font-mono">{app?.ramMb} MB</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Status</p>
              <p className="text-foreground font-mono">
                {app?.status === "running" ? "Ativo" : app?.status === "error" ? "Erro" : "Parado"}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Criada em</p>
              <p className="text-foreground font-mono">
                {app?.createdAt ? new Date(app.createdAt).toLocaleDateString("pt-BR") : "-"}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Logs */}
      <Card className="bg-card border-border/50 p-6">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-foreground">Logs do Console</h3>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                navigator.clipboard.writeText(logs?.logs || "");
                toast.success("Logs copiados!");
              }}
            >
              <Copy className="w-4 h-4 mr-2" />
              Copiar
            </Button>
          </div>
          <div className="bg-background border border-border/50 rounded-lg p-4 h-96 overflow-y-auto font-mono text-sm text-muted-foreground">
            {logs?.logs ? (
              <pre className="whitespace-pre-wrap break-words">{logs.logs}</pre>
            ) : (
              <p className="text-center py-8">Nenhum log disponível</p>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}

function ArquivosTab({ fileStructure }: { fileStructure: any }) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const renderFileTree = (node: any, path: string = "") => {
    if (!node) return null;

    const currentPath = path ? `${path}/${node.name}` : node.name;
    const isExpanded = expandedFolders.has(currentPath);

    return (
      <div key={currentPath} className="space-y-1">
        {node.type === "directory" ? (
          <div>
            <button
              onClick={() => toggleFolder(currentPath)}
              className="flex items-center space-x-2 text-foreground hover:text-accent transition-colors w-full"
            >
              <ChevronRight
                className={`w-4 h-4 transition-transform ${isExpanded ? "rotate-90" : ""}`}
              />
              <Folder className="w-4 h-4 text-accent" />
              <span className="text-sm">{node.name}</span>
            </button>
            {isExpanded && node.children && (
              <div className="ml-4 space-y-1">
                {node.children.map((child: any) => renderFileTree(child, currentPath))}
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center space-x-2 text-muted-foreground">
            <File className="w-4 h-4" />
            <span className="text-sm">{node.name}</span>
            {node.size && <span className="text-xs text-muted-foreground">({node.size} bytes)</span>}
          </div>
        )}
      </div>
    );
  };

  return (
    <Card className="bg-card border-border/50 p-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Estrutura de Arquivos</h3>
        <div className="bg-background border border-border/50 rounded-lg p-4 max-h-[600px] overflow-y-auto">
          {fileStructure ? (
            <div className="space-y-1">{renderFileTree(fileStructure)}</div>
          ) : (
            <p className="text-muted-foreground text-center py-8">Nenhum arquivo encontrado</p>
          )}
        </div>
      </div>
    </Card>
  );
}

function ConfiguracoesTab({ appId }: { appId: number }) {
  const [, setLocation] = useLocation();
  const deleteAppMutation = trpc.applications.delete.useMutation({
    onSuccess: () => {
      toast.success("Aplicação deletada com sucesso!");
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao deletar");
    },
  });

  return (
    <Card className="bg-card border-border/50 p-6">
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground mb-4">Zona de Perigo</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Deletar uma aplicação é uma ação irreversível. Todos os dados serão perdidos.
          </p>
          <Button
            onClick={() => {
              if (
                confirm(
                  "Tem certeza que deseja deletar esta aplicação? Esta ação não pode ser desfeita."
                )
              ) {
                deleteAppMutation.mutate({ appId });
              }
            }}
            disabled={deleteAppMutation.isPending}
            className="bg-destructive hover:bg-destructive/90 text-white"
          >
            {deleteAppMutation.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Deletando...
              </>
            ) : (
              <>
                <Trash2 className="w-4 h-4 mr-2" />
                Deletar Aplicação
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
