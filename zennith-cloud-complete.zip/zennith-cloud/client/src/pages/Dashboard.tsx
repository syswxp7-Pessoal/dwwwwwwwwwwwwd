import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2, Plus, Trash2, FileText } from "lucide-react";

export default function Dashboard() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [isCreatingApp, setIsCreatingApp] = useState(false);

  const { data: userStatus } = trpc.applications.getUserStatus.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const { data: applications, refetch: refetchApps } = trpc.applications.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-accent mx-auto mb-4" />
          <p className="text-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  const ramPercentage = userStatus ? (userStatus.usedRamMb / userStatus.totalRamMb) * 100 : 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">Z</span>
            </div>
            <span className="text-xl font-bold text-foreground glow-neon">Zennith Cloud</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">{user?.name || user?.email}</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                logout();
                setLocation("/");
              }}
            >
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* RAM Card */}
          <Card className="bg-card border-border/50 p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">RAM Disponível</p>
                  <p className="text-2xl font-bold text-foreground">
                    {userStatus?.availableRamMb || 0} MB
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="text-lg font-semibold text-accent">
                    {userStatus?.totalRamMb || 0} MB
                  </p>
                </div>
              </div>
              <div className="w-full bg-card border border-border/50 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-accent to-accent/60 h-full transition-all duration-300"
                  style={{ width: `${ramPercentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground">
                {ramPercentage.toFixed(1)}% utilizado
              </p>
            </div>
          </Card>

          {/* vCPU Card */}
          <Card className="bg-card border-border/50 p-6">
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-muted-foreground">vCPU Disponível</p>
                  <p className="text-2xl font-bold text-foreground">
                    {userStatus?.availableVcpu || 0}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Total</p>
                  <p className="text-lg font-semibold text-accent">
                    {userStatus?.totalVcpu || 0}
                  </p>
                </div>
              </div>
              <div className="w-full bg-card border border-border/50 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-accent to-accent/60 h-full transition-all duration-300"
                  style={{
                    width: `${userStatus ? (userStatus.usedVcpu / userStatus.totalVcpu) * 100 : 0}%`,
                  }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground">
                {userStatus ? ((userStatus.usedVcpu / userStatus.totalVcpu) * 100).toFixed(1) : 0}% utilizado
              </p>
            </div>
          </Card>
        </div>

        {/* Applications Section */}
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-foreground">Minhas Aplicações</h2>
            <Dialog open={isCreatingApp} onOpenChange={setIsCreatingApp}>
              <DialogTrigger asChild>
                <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Aplicação
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border/50">
                <DialogHeader>
                  <DialogTitle className="text-foreground">Criar Nova Aplicação</DialogTitle>
                </DialogHeader>
                <CreateApplicationForm
                  onSuccess={() => {
                    setIsCreatingApp(false);
                    refetchApps();
                  }}
                  availableRam={userStatus?.availableRamMb || 0}
                />
              </DialogContent>
            </Dialog>
          </div>

          {/* Applications Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {applications && applications.length > 0 ? (
              applications.map((app) => (
                <Card
                  key={app.id}
                  className="bg-card border-border/50 p-6 cursor-pointer hover:border-accent/50 transition-colors"
                  onClick={() => (window.location.href = `/app/${app.id}`)}
                >
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-bold text-foreground text-lg">{app.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {app.description || "Sem descrição"}
                        </p>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          app.status === "running"
                            ? "bg-green-500/20 text-green-400"
                            : app.status === "error"
                              ? "bg-red-500/20 text-red-400"
                              : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {app.status === "running" ? "Ativo" : app.status === "error" ? "Erro" : "Parado"}
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <p className="text-muted-foreground">
                        RAM: <span className="text-foreground font-semibold">{app.ramMb}MB</span>
                      </p>
                      <p className="text-muted-foreground">
                        Entrada: <span className="text-foreground font-semibold">{app.entryPoint}</span>
                      </p>
                    </div>

                    <div className="flex gap-2 pt-4">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.location.href = `/app/${app.id}`;
                        }}
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Gerenciar
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-destructive hover:text-destructive"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm("Tem certeza que deseja deletar esta aplicação?")) {
                            // deleteAppMutation.mutate({ appId: app.id });
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground mb-4">Nenhuma aplicação criada ainda</p>
                <Button
                  onClick={() => setIsCreatingApp(true)}
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                >
                  Criar Primeira Aplicação
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function CreateApplicationForm({
  onSuccess,
  availableRam,
}: {
  onSuccess: () => void;
  availableRam: number;
}) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    ramMb: 256,
    entryPoint: "",
    zipFile: null as File | null,
  });
  const [isUploading, setIsUploading] = useState(false);

  const uploadMutation = trpc.upload.uploadZip.useMutation();
  const createMutation = trpc.applications.create.useMutation();

  const handleCreateSuccess = () => {
    toast.success("Aplicação criada com sucesso!");
    setIsUploading(false);
    setFormData({ name: "", description: "", ramMb: 256, entryPoint: "", zipFile: null });
    onSuccess();
  };

  const handleCreateError = (error: any) => {
    toast.error(error.message || "Erro ao criar aplicação");
    setIsUploading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.entryPoint || !formData.zipFile) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    if (formData.ramMb < 256) {
      toast.error("RAM mínima é 256MB");
      return;
    }

    if (formData.ramMb > availableRam) {
      toast.error(`RAM indisponível. Máximo: ${availableRam}MB`);
      return;
    }

    setIsUploading(true);
    try {
      if (!formData.zipFile) {
        toast.error("Arquivo ZIP não selecionado");
        setIsUploading(false);
        return;
      }

      const fileBuffer = await formData.zipFile.arrayBuffer();
      const uploadResult = await uploadMutation.mutateAsync({
        fileName: formData.zipFile.name,
        fileData: new Uint8Array(fileBuffer),
      });

      if (!uploadResult || !uploadResult.success) {
        toast.error("Erro ao fazer upload do arquivo");
        setIsUploading(false);
        return;
      }

      console.log("[CreateApp] Upload successful, creating application...");
      createMutation.mutate(
        {
          name: formData.name,
          description: formData.description,
          ramMb: formData.ramMb,
          entryPoint: formData.entryPoint,
          zipFileUrl: uploadResult.url,
          zipFileKey: uploadResult.key,
          zipLocalPath: uploadResult.localPath,
        },
        {
          onSuccess: handleCreateSuccess,
          onError: handleCreateError,
        }
      );
    } catch (error) {
      console.error("[CreateApp] Error:", error);
      if (!(error instanceof Error && error.message.includes("Erro ao criar aplicação"))) {
        toast.error(error instanceof Error ? error.message : "Erro ao fazer upload do arquivo");
      }
      setIsUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="text-sm font-medium text-foreground">Nome da Aplicação *</label>
        <Input
          placeholder="Meu Bot"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="bg-input border-border/50 text-foreground mt-1"
        />
      </div>

      <div>
        <label className="text-sm font-medium text-foreground">Descrição</label>
        <Textarea
          placeholder="Descrição opcional..."
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          className="bg-input border-border/50 text-foreground mt-1"
        />
      </div>

      <div>
        <label className="text-sm font-medium text-foreground">RAM (MB) *</label>
        <Input
          type="number"
          min="256"
          max={availableRam}
          value={formData.ramMb}
          onChange={(e) => setFormData({ ...formData, ramMb: parseInt(e.target.value) })}
          className="bg-input border-border/50 text-foreground mt-1"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Disponível: {availableRam}MB
        </p>
      </div>

      <div>
        <label className="text-sm font-medium text-foreground">Arquivo Principal (EntryPoint) *</label>
        <Input
          placeholder="index.js ou main.py"
          value={formData.entryPoint}
          onChange={(e) => setFormData({ ...formData, entryPoint: e.target.value })}
          className="bg-input border-border/50 text-foreground mt-1"
        />
      </div>

      <div>
        <label className="text-sm font-medium text-foreground">Arquivo ZIP *</label>
        <Input
          type="file"
          accept=".zip"
          onChange={(e) => setFormData({ ...formData, zipFile: e.target.files?.[0] || null })}
          className="bg-input border-border/50 text-foreground mt-1"
        />
      </div>

      <div className="flex gap-2 pt-4">
        <Button
          type="submit"
          disabled={isUploading || createMutation.isPending}
          className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
        >
          {isUploading || createMutation.isPending ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              {isUploading ? "Enviando..." : "Criando..."}
            </>
          ) : (
            "Criar Aplicação"
          )}
        </Button>
      </div>
    </form>
  );
}
