import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (isAuthenticated && !loading) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, loading, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent mx-auto mb-4"></div>
          <p className="text-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Background gradient effect */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-background to-background"></div>
        <div className="absolute top-0 -left-40 w-80 h-80 bg-accent/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 -right-40 w-80 h-80 bg-accent/20 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-10 border-b border-border/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">Z</span>
            </div>
            <span className="text-xl font-bold text-foreground glow-neon">Zennith Cloud</span>
          </div>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            Entrar
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 container mx-auto px-4 py-20 md:py-32">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left side - Text */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                Hospede seus{" "}
                <span className="bg-gradient-to-r from-accent via-accent/80 to-accent/60 bg-clip-text text-transparent glow-neon-lg">
                  Bots
                </span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Plataforma de hospedagem rápida, segura e escalável para seus bots em Node.js e Python. Comece com 1GB de RAM e 1 vCPU gratuitamente.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg font-semibold"
              >
                Começar Agora
              </Button>
              <Button
                variant="outline"
                className="border-border hover:bg-card px-8 py-6 text-lg font-semibold"
              >
                Saiba Mais
              </Button>
            </div>

            {/* Features list */}
            <div className="space-y-3 pt-8">
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 rounded-full bg-accent/30 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <span className="text-foreground">Deploy em segundos</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 rounded-full bg-accent/30 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <span className="text-foreground">Suporte a Node.js e Python</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 rounded-full bg-accent/30 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-accent"></div>
                </div>
                <span className="text-foreground">Monitoramento em tempo real</span>
              </div>
            </div>
          </div>

          {/* Right side - Visual */}
          <div className="relative hidden md:block">
            <div className="relative w-full aspect-square">
              {/* Animated cards */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="relative w-72 h-96">
                  {/* Card 1 */}
                  <div className="absolute inset-0 bg-card border border-accent/30 rounded-xl p-6 shadow-2xl transform -rotate-6 hover:rotate-0 transition-transform duration-300">
                    <div className="space-y-4">
                      <div className="w-12 h-12 bg-accent/20 rounded-lg"></div>
                      <div className="space-y-2">
                        <div className="h-3 bg-accent/20 rounded w-3/4"></div>
                        <div className="h-3 bg-accent/10 rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>

                  {/* Card 2 */}
                  <div className="absolute inset-0 bg-card border border-accent/30 rounded-xl p-6 shadow-2xl transform rotate-6 hover:rotate-0 transition-transform duration-300 translate-y-8">
                    <div className="space-y-4">
                      <div className="w-12 h-12 bg-accent/20 rounded-lg"></div>
                      <div className="space-y-2">
                        <div className="h-3 bg-accent/20 rounded w-3/4"></div>
                        <div className="h-3 bg-accent/10 rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="relative z-10 container mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="text-4xl font-bold text-accent mb-2">99.9%</div>
            <p className="text-muted-foreground">Uptime garantido</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-accent mb-2">&lt;1s</div>
            <p className="text-muted-foreground">Deploy instantâneo</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-accent mb-2">∞</div>
            <p className="text-muted-foreground">Escalabilidade</p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative z-10 container mx-auto px-4 py-16 md:py-24">
        <div className="bg-card border border-accent/30 rounded-2xl p-12 text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Pronto para começar?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Crie sua conta agora e receba 1GB de RAM + 1 vCPU gratuitamente. Sem cartão de crédito necessário.
          </p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-6 text-lg font-semibold"
          >
            Criar Conta
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8 text-center text-muted-foreground">
          <p>&copy; 2025 Zennith Cloud. Todos os direitos reservados.</p>
        </div>
      </footer>

      <style>{`
        @keyframes blob {
          0%, 100% {
            transform: translate(0, 0) scale(1);
          }
          33% {
            transform: translate(30px, -50px) scale(1.1);
          }
          66% {
            transform: translate(-20px, 20px) scale(0.9);
          }
        }
        
        .animate-blob {
          animation: blob 7s infinite;
        }
        
        .animation-delay-2000 {
          animation-delay: 2s;
        }
      `}</style>
    </div>
  );
}
