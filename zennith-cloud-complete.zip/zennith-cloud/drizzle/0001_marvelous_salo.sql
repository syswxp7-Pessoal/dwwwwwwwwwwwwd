CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`ramMb` int NOT NULL,
	`vcpu` int NOT NULL DEFAULT 1,
	`entryPoint` varchar(255) NOT NULL,
	`zipFileKey` varchar(255) NOT NULL,
	`zipFileUrl` varchar(512) NOT NULL,
	`status` enum('stopped','running','error') NOT NULL DEFAULT 'stopped',
	`processId` varchar(64),
	`logs` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `totalRamMb` int DEFAULT 1024 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `usedRamMb` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalVcpu` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `usedVcpu` int DEFAULT 0 NOT NULL;