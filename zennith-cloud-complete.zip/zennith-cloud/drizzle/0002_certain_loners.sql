CREATE TABLE `accessStatistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`applicationId` int,
	`language` varchar(50),
	`accessedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accessStatistics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `adminCredentials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminCredentials_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminCredentials_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `adminPermissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`canManageUsers` int NOT NULL DEFAULT 0,
	`canManagePermissions` int NOT NULL DEFAULT 0,
	`canViewStatistics` int NOT NULL DEFAULT 1,
	`canEditResources` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminPermissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminPermissions_email_unique` UNIQUE(`email`)
);
