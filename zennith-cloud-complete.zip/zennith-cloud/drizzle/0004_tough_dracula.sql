DROP TABLE `accessStatistics`;--> statement-breakpoint
DROP TABLE `adminCredentials`;--> statement-breakpoint
DROP TABLE `adminPermissions`;--> statement-breakpoint
DROP TABLE `applications`;--> statement-breakpoint
DROP TABLE `localUsers`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `totalRamMb`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `usedRamMb`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `totalVcpu`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `usedVcpu`;