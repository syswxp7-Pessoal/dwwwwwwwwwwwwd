CREATE TABLE `accessStatistics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`applicationId` int,
	`language` varchar(50),
	`accessedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accessStatistics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `adminCredentials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminCredentials_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminCredentials_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `adminPermissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`canManageUsers` int NOT NULL DEFAULT 0,
	`canManagePermissions` int NOT NULL DEFAULT 0,
	`canViewStatistics` int NOT NULL DEFAULT 1,
	`canEditResources` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `adminPermissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `adminPermissions_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE TABLE `applications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`ramMb` int NOT NULL,
	`vcpu` int NOT NULL DEFAULT 1,
	`entryPoint` varchar(255) NOT NULL,
	`zipFileKey` varchar(255) NOT NULL,
	`zipFileUrl` varchar(512) NOT NULL,
	`status` enum('stopped','running','error') NOT NULL DEFAULT 'stopped',
	`processId` varchar(64),
	`logs` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `applications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `totalRamMb` int DEFAULT 1024 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `usedRamMb` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `totalVcpu` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `usedVcpu` int DEFAULT 0 NOT NULL;