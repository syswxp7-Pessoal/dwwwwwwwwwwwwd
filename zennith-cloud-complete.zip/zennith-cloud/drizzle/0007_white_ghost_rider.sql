DROP TABLE `apiKeyHistory`;--> statement-breakpoint
ALTER TABLE `users` DROP INDEX `users_apiKey_unique`;--> statement-breakpoint
ALTER TABLE `users` DROP COLUMN `apiKey`;