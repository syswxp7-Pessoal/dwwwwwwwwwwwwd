import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }), // Senha do usuário (opcional)
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Recursos alocados para o usuário (em MB)
  totalRamMb: int("totalRamMb").default(1024).notNull(), // 1GB padrão
  usedRamMb: int("usedRamMb").default(0).notNull(),
  totalVcpu: int("totalVcpu").default(1).notNull(),
  usedVcpu: int("usedVcpu").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Tabela de aplicações (bots)
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  ramMb: int("ramMb").notNull(), // RAM alocada para esta aplicação
  vcpu: int("vcpu").default(1).notNull(),
  entryPoint: varchar("entryPoint", { length: 255 }).notNull(), // Arquivo principal (ex: index.js, main.py)
  zipFileKey: varchar("zipFileKey", { length: 255 }).notNull(), // Chave do arquivo no S3
  zipFileUrl: varchar("zipFileUrl", { length: 512 }).notNull(), // URL do arquivo no S3
  status: mysqlEnum("status", ["stopped", "running", "error"]).default("stopped").notNull(),
  processId: varchar("processId", { length: 64 }), // PID do processo em execução
  logs: text("logs"), // Logs da aplicação
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

// Tabela de credenciais admin
export const adminCredentials = mysqlTable("adminCredentials", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminCredential = typeof adminCredentials.$inferSelect;
export type InsertAdminCredential = typeof adminCredentials.$inferInsert;

// Tabela de permissões de usuários admin
export const adminPermissions = mysqlTable("adminPermissions", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull().unique(),
  canManageUsers: int("canManageUsers").default(0).notNull(), // 0 = false, 1 = true
  canManagePermissions: int("canManagePermissions").default(0).notNull(),
  canViewStatistics: int("canViewStatistics").default(1).notNull(),
  canEditResources: int("canEditResources").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AdminPermission = typeof adminPermissions.$inferSelect;
export type InsertAdminPermission = typeof adminPermissions.$inferInsert;

// Tabela de estatísticas de acesso
export const accessStatistics = mysqlTable("accessStatistics", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"),
  applicationId: int("applicationId"),
  language: varchar("language", { length: 50 }), // node, python, etc
  accessedAt: timestamp("accessedAt").defaultNow().notNull(),
});

export type AccessStatistic = typeof accessStatistics.$inferSelect;
export type InsertAccessStatistic = typeof accessStatistics.$inferInsert;