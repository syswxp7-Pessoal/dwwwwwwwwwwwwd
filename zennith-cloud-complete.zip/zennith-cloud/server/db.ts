import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, applications, InsertApplication, Application } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createApplication(app: InsertApplication) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.insert(applications).values(app);
  
  // Obter o ID da aplicação criada
  // Para MySQL/TiDB, o insertId pode estar em result[0] ou result.insertId
  let appId: number | undefined;
  
  if (Array.isArray(result) && result.length > 0 && typeof result[0] === 'object') {
    appId = (result[0] as any).id || (result[0] as any).insertId;
  } else if (typeof result === 'object') {
    appId = (result as any).insertId || (result as any).id;
  }
  
  if (!appId) {
    // Se não conseguir obter o ID, fazer uma query para obter a aplicação mais recente
    const apps = await db.select().from(applications).where(eq(applications.userId, app.userId)).orderBy(desc(applications.id)).limit(1);
    if (apps.length > 0) {
      appId = apps[0].id;
    }
  }
  
  return { insertId: appId, ...result };
}

export async function getApplicationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) {
    return [];
  }

  return await db.select().from(applications).where(eq(applications.userId, userId));
}

export async function getApplicationById(appId: number) {
  const db = await getDb();
  if (!db) {
    return undefined;
  }

  const result = await db.select().from(applications).where(eq(applications.id, appId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateApplication(appId: number, updates: Partial<Application>) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(applications).set(updates).where(eq(applications.id, appId));
}

export async function deleteApplication(appId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.delete(applications).where(eq(applications.id, appId));
}

export async function updateUserResources(userId: number, updates: { usedRamMb?: number; usedVcpu?: number }) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(users).set(updates).where(eq(users.id, userId));
}
