import { spawn, ChildProcess, execSync } from "child_process";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";

interface ProcessInfo {
  process: ChildProcess;
  logs: string[];
  startTime: Date;
  appId: number;
}

const runningProcesses = new Map<number, ProcessInfo>();

/**
 * Extrai a linguagem do arquivo baseado na extensão
 */
function getLanguageFromFile(filePath: string): "node" | "python" | null {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".js" || ext === ".ts" || ext === ".mjs") {
    return "node";
  }
  if (ext === ".py") {
    return "python";
  }
  return null;
}

/**
 * Inicia um processo de aplicação
 */
export async function startApplication(
  appId: number,
  workDir: string,
  entryPoint: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // Verifica se já existe um processo em execução
    if (runningProcesses.has(appId)) {
      return { success: false, error: "Application is already running" };
    }

    // Verifica se o arquivo de entrada existe
    const entryPointPath = path.join(workDir, entryPoint);
    if (!fs.existsSync(entryPointPath)) {
      return { success: false, error: "Entry point file not found" };
    }

    // Determina a linguagem
    const language = getLanguageFromFile(entryPoint);
    if (!language) {
      return {
        success: false,
        error: "Unsupported file type. Only .js, .ts, .mjs, and .py are supported",
      };
    }

    // Prepara o comando
    let command: string = "";
    let args: string[] = [];

    if (language === "node") {
      command = "node";
      args = [entryPoint];
    } else {
      // Tenta encontrar Python usando caminhos comuns
      const pythonPaths = [
        '/usr/bin/python3.11',
        '/usr/bin/python3.10',
        '/usr/bin/python3',
        '/usr/bin/python',
        '/usr/local/bin/python3',
        '/usr/local/bin/python',
        'python3',
        'python'
      ];
      
      let pythonFound = false;
      let pythonError = '';
      
      for (const pythonPath of pythonPaths) {
        try {
          console.log(`[App ${appId}] Tentando Python em: ${pythonPath}`);
          
          // Verifica se o arquivo existe
          if (fs.existsSync(pythonPath)) {
            console.log(`[App ${appId}] Arquivo encontrado: ${pythonPath}`);
            // Testa se o comando funciona
            try {
              const version = execSync(`${pythonPath} --version`, { 
                stdio: 'pipe', 
                timeout: 5000,
                env: { ...process.env }
              });
              console.log(`[App ${appId}] Python funcional: ${pythonPath} - ${version.toString().trim()}`);
              command = pythonPath;
              pythonFound = true;
              break;
            } catch (e: any) {
              pythonError = `Erro ao testar ${pythonPath}: ${e.message}`;
              console.log(`[App ${appId}] ${pythonError}`);
              continue;
            }
          } else if (pythonPath === 'python3' || pythonPath === 'python') {
            // Tenta usar o comando direto (pode estar no PATH)
            try {
              const version = execSync(`${pythonPath} --version`, { 
                stdio: 'pipe', 
                timeout: 5000,
                env: { ...process.env, PATH: process.env.PATH }
              });
              console.log(`[App ${appId}] Python funcional via PATH: ${pythonPath}`);
              command = pythonPath;
              pythonFound = true;
              break;
            } catch (e: any) {
              pythonError = `Erro ao testar ${pythonPath}: ${e.message}`;
              console.log(`[App ${appId}] ${pythonError}`);
              continue;
            }
          }
        } catch (e: any) {
          pythonError = `Erro ao processar ${pythonPath}: ${e.message}`;
          console.log(`[App ${appId}] ${pythonError}`);
          continue;
        }
      }
      
      if (!pythonFound) {
        const errorMsg = `Python is not installed on the system. Tried: ${pythonPaths.join(', ')}. Last error: ${pythonError}`;
        console.error(`[App ${appId}] ${errorMsg}`);
        return {
          success: false,
          error: errorMsg
        };
      }
      
      args = [entryPoint];
    }
    
    // Validar que command foi definido
    if (!command) {
      return {
        success: false,
        error: "Failed to determine command to execute"
      };
    }

    // Inicia o processo
    console.log(`[App ${appId}] Starting ${language} process: ${command} ${args.join(' ')}`);
    console.log(`[App ${appId}] Working directory: ${workDir}`);
    console.log(`[App ${appId}] Environment PATH: ${process.env.PATH}`);
    
    // Preparar ambiente com PATH completo
    const env = {
      ...process.env,
      NODE_ENV: "production",
      PATH: `/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:${process.env.PATH || ''}`
    };
    
    console.log(`[App ${appId}] Usando comando: ${command}`);
    console.log(`[App ${appId}] Com PATH: ${env.PATH}`);
    
    const childProcess = spawn(command, args, {
      cwd: workDir,
      stdio: ["pipe", "pipe", "pipe"],
      detached: false,
      shell: true,
      env: env
    });

    console.log(`[App ${appId}] Process spawned with PID: ${childProcess.pid}`);
    
    // Se o PID for null, significa que o processo não foi criado
    if (!childProcess.pid) {
      console.error(`[App ${appId}] Falha ao criar processo - PID é null`);
    }

    const logs: string[] = [];
    logs.push(`\n========================================\n`);
    logs.push(`[${new Date().toISOString()}] Aplicacao iniciada\n`);
    logs.push(`Comando: ${command} ${args.join(' ')}\n`);
    logs.push(`Diretorio: ${workDir}\n`);
    logs.push(`========================================\n\n`);
    logs.push(`[${new Date().toISOString()}] Executando: ${command} ${args.join(' ')}\n`);

    // Captura stdout
    childProcess.stdout?.on("data", (data) => {
      const message = data.toString();
      logs.push(`[${new Date().toISOString()}] ${message}`);
      console.log(`[App ${appId}] STDOUT: ${message}`);
    });

    // Captura stderr
    childProcess.stderr?.on("data", (data) => {
      const message = data.toString();
      logs.push(`[${new Date().toISOString()}] [STDERR] ${message}`);
      console.error(`[App ${appId}] STDERR: ${message}`);
    });

    // Monitora o término do processo
    childProcess.on("exit", (code, signal) => {
      const exitMsg = `\n[${new Date().toISOString()}] Process exited with code ${code} (signal: ${signal})`;
      logs.push(exitMsg);
      console.log(`[App ${appId}] ${exitMsg}`);
      if (runningProcesses.has(appId)) {
        runningProcesses.delete(appId);
      }
    });
    
    childProcess.on("close", (code, signal) => {
      const closeMsg = `\n[${new Date().toISOString()}] Process closed with code ${code}`;
      logs.push(closeMsg);
      console.log(`[App ${appId}] ${closeMsg}`);
      if (runningProcesses.has(appId)) {
        runningProcesses.delete(appId);
      }
    });
    
    childProcess.on("error", (error: any) => {
      const errorMsg = `\n[${new Date().toISOString()}] Process error: ${error.message}`;
      logs.push(errorMsg);
      console.error(`[App ${appId}] ${errorMsg}`);
      console.error(`[App ${appId}] Error code: ${error.code}`);
      console.error(`[App ${appId}] Error details:`, error);
      runningProcesses.delete(appId);
    });

    // Armazena a informação do processo
    runningProcesses.set(appId, {
      process: childProcess,
      logs,
      startTime: new Date(),
      appId,
    });

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Para um processo de aplicação
 */
export async function stopApplication(
  appId: number
): Promise<{ success: boolean; error?: string }> {
  try {
    const processInfo = runningProcesses.get(appId);
    if (!processInfo) {
      return { success: false, error: "Application is not running" };
    }

    console.log(`[App ${appId}] Stopping process with PID: ${processInfo.process.pid}`);

    // Tenta terminar o processo gracefully
    processInfo.process.kill("SIGTERM");

    // Aguarda um pouco e força se necessário
    await new Promise((resolve) => setTimeout(resolve, 1000));
    if (!processInfo.process.killed) {
      console.log(`[App ${appId}] Force killing process`);
      processInfo.process.kill("SIGKILL");
    }

    console.log(`[App ${appId}] Process stopped`);

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Reinicia um processo de aplicação
 */
export async function restartApplication(
  appId: number,
  workDir: string,
  entryPoint: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // Para o processo atual
    await stopApplication(appId);

    // Aguarda um pouco
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Inicia novamente
    return await startApplication(appId, workDir, entryPoint);
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

/**
 * Obtém os logs de uma aplicação
 */
export function getApplicationLogs(appId: number): string {
  const processInfo = runningProcesses.get(appId);
  if (!processInfo) {
    return "";
  }
  return processInfo.logs.join("");
}

/**
 * Limpa os logs de uma aplicação
 */
export function clearApplicationLogs(appId: number): void {
  const processInfo = runningProcesses.get(appId);
  if (processInfo) {
    processInfo.logs = [];
  }
}

/**
 * Verifica se uma aplicação está em execução
 */
export function isApplicationRunning(appId: number): boolean {
  return runningProcesses.has(appId);
}

/**
 * Obtém informações sobre uma aplicação em execução
 */
export function getApplicationStatus(
  appId: number
): { running: boolean; uptime?: number; logsCount?: number } {
  const processInfo = runningProcesses.get(appId);
  if (!processInfo) {
    return { running: false };
  }

  const uptime = Date.now() - processInfo.startTime.getTime();
  return {
    running: true,
    uptime,
    logsCount: processInfo.logs.length,
  };
}
