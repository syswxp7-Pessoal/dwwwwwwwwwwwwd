import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import * as processManager from "./processManager";
import * as zipManager from "./zipManager";
import * as path from "path";
import * as fs from "fs";
import * as os from "os";
import { uploadRouter } from "./uploadRouter";
import * as crypto from "crypto";
import { eq } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  upload: uploadRouter,

  admin: router({
    // Login admin
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        // Busca as credenciais admin
        const adminDb = await db.getDb();
        if (!adminDb) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database not available" });
        }

        const { adminCredentials } = await import("../drizzle/schema");
        const result = await adminDb
          .select()
          .from(adminCredentials)
          .where(eq(adminCredentials.email, input.email))
          .limit(1);

        const admin = result[0];
        if (!admin) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
        }

        // Verifica a senha
        const passwordHash = crypto.createHash("sha256").update(input.password).digest("hex");
        if (passwordHash !== admin.passwordHash) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
        }

        // Busca as permissões do admin
        const { adminPermissions } = await import("../drizzle/schema");
        const permResult = await adminDb
          .select()
          .from(adminPermissions)
          .where(eq(adminPermissions.email, input.email))
          .limit(1);

        const permissions = permResult[0];

        // Cria um token de sessão
        const token = crypto.randomBytes(32).toString("hex");
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie("admin_token", token, { ...cookieOptions, maxAge: 24 * 60 * 60 * 1000 });
        ctx.res.cookie("admin_email", input.email, { ...cookieOptions, maxAge: 24 * 60 * 60 * 1000 });

        return {
          success: true,
          email: input.email,
          permissions: {
            canManageUsers: permissions?.canManageUsers === 1,
            canManagePermissions: permissions?.canManagePermissions === 1,
            canViewStatistics: permissions?.canViewStatistics === 1,
            canEditResources: permissions?.canEditResources === 1,
          },
        };
      }),

    // Verificar se está logado como admin
    me: publicProcedure.query(({ ctx }) => {
      const adminEmail = ctx.req.cookies?.admin_email;
      const adminToken = ctx.req.cookies?.admin_token;
      
      if (!adminEmail || !adminToken) {
        return null;
      }
      
      return { email: adminEmail };
    }),

    // Logout admin
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie("admin_token", { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie("admin_email", { ...cookieOptions, maxAge: -1 });
      return { success: true };
    }),

    // Obter estatísticas
    getStatistics: publicProcedure.query(async () => {
      const adminDb = await db.getDb();
      if (!adminDb) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      }

      const { users, applications, accessStatistics } = await import("../drizzle/schema");

      // Total de usuários
      const userCount = await adminDb.select().from(users);

      // Total de aplicações
      const appCount = await adminDb.select().from(applications);

      // Linguagens mais usadas
      const langStats = await adminDb.select().from(accessStatistics);
      const langMap: Record<string, number> = {};
      langStats.forEach((stat: any) => {
        if (stat.language) {
          langMap[stat.language] = (langMap[stat.language] || 0) + 1;
        }
      });

      const topLanguages = Object.entries(langMap)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([lang, count]) => ({ language: lang, count }));

      return {
        totalUsers: userCount.length,
        totalApplications: appCount.length,
        topLanguages,
      };
    }),

    // Listar todos os usuários
    listUsers: publicProcedure
      .input(z.object({ search: z.string().optional() }))
      .query(async ({ input }) => {
        const adminDb = await db.getDb();
        if (!adminDb) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }

        const { users } = await import("../drizzle/schema");
        let query = adminDb.select().from(users);

        if (input.search) {
          // Implementar busca por email
          const allUsers = await query;
          return allUsers.filter((u: any) => u.email?.includes(input.search));
        }

        return await query;
      }),

    // Atualizar recursos do usuário
    updateUserResources: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          totalRamMb: z.number().optional(),
          totalVcpu: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const updates: any = {};
        if (input.totalRamMb !== undefined) updates.totalRamMb = input.totalRamMb;
        if (input.totalVcpu !== undefined) updates.totalVcpu = input.totalVcpu;

        await db.updateUserResources(input.userId, updates);
        return { success: true };
      }),

    // Adicionar novo admin
    addAdmin: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input }) => {
        const adminDb = await db.getDb();
        if (!adminDb) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }

        const { adminCredentials, adminPermissions } = await import("../drizzle/schema");
        const passwordHash = crypto.createHash("sha256").update(input.password).digest("hex");

        try {
          await adminDb.insert(adminCredentials).values({
            email: input.email,
            passwordHash,
          });

          await adminDb.insert(adminPermissions).values({
            email: input.email,
            canManageUsers: 0,
            canManagePermissions: 0,
            canViewStatistics: 1,
            canEditResources: 0,
          });

          return { success: true };
        } catch (error) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Admin already exists" });
        }
      }),

    // Atualizar permissões de admin
    updateAdminPermissions: publicProcedure
      .input(
        z.object({
          email: z.string().email(),
          canManageUsers: z.boolean().optional(),
          canManagePermissions: z.boolean().optional(),
          canViewStatistics: z.boolean().optional(),
          canEditResources: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const adminDb = await db.getDb();
        if (!adminDb) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
        }

        const { adminPermissions } = await import("../drizzle/schema");
        const updates: any = {};

        if (input.canManageUsers !== undefined) updates.canManageUsers = input.canManageUsers ? 1 : 0;
        if (input.canManagePermissions !== undefined) updates.canManagePermissions = input.canManagePermissions ? 1 : 0;
        if (input.canViewStatistics !== undefined) updates.canViewStatistics = input.canViewStatistics ? 1 : 0;
        if (input.canEditResources !== undefined) updates.canEditResources = input.canEditResources ? 1 : 0;

        await adminDb.update(adminPermissions).set(updates).where(eq(adminPermissions.email, input.email));
        return { success: true };
      }),
  }),

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  applications: router({
    // Listar aplicacoes do usuario
    list: protectedProcedure.query(async ({ ctx }) => {
      const apps = await db.getApplicationsByUserId(ctx.user.id);
      return apps;
    }),

    // Obter informacoes de uma aplicacao especifica
    get: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .query(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return app;
      }),

    // Criar nova aplicacao
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          description: z.string().optional(),
          ramMb: z.number().min(256),
          zipFileKey: z.string(),
          zipFileUrl: z.string(),
          zipLocalPath: z.string().optional(),
          entryPoint: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Obtem informacoes do usuario
        const user = await db.getUserById(ctx.user.id);
        if (!user) {
          throw new TRPCError({ code: "NOT_FOUND", message: "User not found" });
        }

        // Verifica se ha RAM disponivel
        const availableRam = user.totalRamMb - user.usedRamMb;
        if (input.ramMb > availableRam) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: `Insufficient RAM. Available: ${availableRam}MB, Requested: ${input.ramMb}MB`,
          });
        }

        // Cria a aplicacao no banco de dados primeiro para obter o ID
        const result = await db.createApplication({
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          ramMb: input.ramMb,
          entryPoint: input.entryPoint,
          zipFileKey: input.zipFileKey,
          zipFileUrl: input.zipFileUrl,
          status: "stopped",
        });

        // Obtem o ID da aplicacao do resultado da insercao
        const appId = (result as any).insertId;
        if (!appId) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to get application ID from database",
          });
        }

        // Cria o diretorio de trabalho para a aplicacao usando o appId
        const appsDir = path.join(os.homedir(), ".zennith-cloud", "apps");
        const appDir = path.join(appsDir, `app-${appId}`);

        if (!fs.existsSync(appsDir)) {
          fs.mkdirSync(appsDir, { recursive: true });
        }

          // Baixa e extrai o arquivo ZIP
        const zipPath = path.join(appsDir, `${appId}.zip`);

        // Usa o arquivo local se disponível, senão tenta baixar do S3
        console.log(`[App ${appId}] Using ZIP file from: ${input.zipLocalPath || input.zipFileUrl}`);
        try {
          if (input.zipLocalPath && fs.existsSync(input.zipLocalPath)) {
            // Copia o arquivo local
            console.log(`[App ${appId}] Copying local ZIP file`);
            fs.copyFileSync(input.zipLocalPath, zipPath);
            console.log(`[App ${appId}] ZIP file copied to: ${zipPath}`);
          } else {
            // Tenta baixar do S3
            console.log(`[App ${appId}] Downloading ZIP from S3`);
            const response = await fetch(input.zipFileUrl);
            console.log(`[App ${appId}] Download response status: ${response.status}`);
            if (!response.ok) {
              throw new Error(`HTTP ${response.status}`);
            }
            const buffer = await response.arrayBuffer();
            console.log(`[App ${appId}] Downloaded ${buffer.byteLength} bytes`);
            fs.writeFileSync(zipPath, Buffer.from(buffer));
            console.log(`[App ${appId}] ZIP file saved to: ${zipPath}`);
          }
        } catch (error) {
          console.error(`[App ${appId}] Failed to get ZIP file: ${error}`);
          await db.deleteApplication(appId);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: `Failed to get ZIP file: ${error}`,
          });
        }

        // Extrai o arquivo ZIP
        console.log(`[App ${appId}] Extracting ZIP from: ${zipPath} to: ${appDir}`);
        const extractResult = await zipManager.extractZip(zipPath, appDir);
        console.log(`[App ${appId}] Extract result:`, extractResult);

        if (!extractResult.success) {
          await db.deleteApplication(appId);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to extract ZIP file",
          });
        }

        // Instala dependencias
        console.log(`[App ${appId}] Installing dependencies...`);
        const installResult = await zipManager.installDependencies(appDir);
        if (!installResult.success) {
          console.error(`[App ${appId}] Failed to install dependencies: ${installResult.error}`);
          // Nao falha a criacao da aplicacao se as dependencias nao forem instaladas
          // O usuario pode tentar instalar manualmente depois
        } else {
          console.log(`[App ${appId}] Dependencies installed successfully`);
        }

        // Atualiza os recursos do usuario
        await db.updateUserResources(ctx.user.id, {
          usedRamMb: user.usedRamMb + input.ramMb,
        });

        // Limpa o arquivo ZIP
        try {
          fs.unlinkSync(zipPath);
        } catch (e) {
          console.warn(`Failed to delete ZIP file: ${e}`);
        }

        // Atualiza a aplicacao com o status
        await db.updateApplication(appId, { status: "stopped" });

        // Retorna o ID da aplicacao
        return { appId };
      }),

    // Deletar aplicacao
    delete: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Para a aplicacao se estiver em execucao
        if (processManager.isApplicationRunning(input.appId)) {
          await processManager.stopApplication(input.appId);
        }

        // Obtem o usuario para liberar recursos
        const user = await db.getUserById(ctx.user.id);
        if (user) {
          await db.updateUserResources(ctx.user.id, {
            usedRamMb: Math.max(0, user.usedRamMb - app.ramMb),
          });
        }

        // Deleta a aplicacao se houver erro na extracao
        try {
          await db.deleteApplication(input.appId);
        } catch (e) {
          console.warn(`Failed to delete application: ${e}`);
        }
        // Deleta o diretorio da aplicacao
        const appsDir = path.join(os.homedir(), ".zennith-cloud", "apps");
        const appDir = path.join(appsDir, `app-${input.appId}`);
        if (fs.existsSync(appDir)) {
          fs.rmSync(appDir, { recursive: true, force: true });
        }

        return { success: true };
      }),

    // Iniciar aplicacao
    start: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        console.log(`[API] Starting application ${input.appId}`);
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          console.warn(`[API] Application ${input.appId} not found or unauthorized`);
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        console.log(`[API] Application found: ${app.name}`);

        if (processManager.isApplicationRunning(input.appId)) {
          console.warn(`[API] Application ${input.appId} is already running`);
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Application is already running",
          });
        }

        const appsDir = path.join(os.homedir(), ".zennith-cloud", "apps");
        const appDir = path.join(appsDir, `app-${input.appId}`);

        console.log(`[API] App directory: ${appDir}`);
        console.log(`[API] Entry point: ${app.entryPoint}`);

        const result = await processManager.startApplication(
          input.appId,
          appDir,
          app.entryPoint
        );

        console.log(`[API] Start result:`, result);

        if (!result.success) {
          console.error(`[API] Failed to start application: ${result.error}`);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: result.error || "Failed to start application",
          });
        }

        // Atualiza o status da aplicacao
        console.log(`[API] Updating application status to running`);
        await db.updateApplication(input.appId, { status: "running" });

        console.log(`[API] Application ${input.appId} started successfully`);
        return { success: true };
      }),

    // Parar aplicacao
    stop: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        const result = await processManager.stopApplication(input.appId);

        if (!result.success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: result.error || "Failed to stop application",
          });
        }

        // Atualiza o status da aplicacao
        await db.updateApplication(input.appId, { status: "stopped" });

        return { success: true };
      }),

    // Reiniciar aplicacao
    restart: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        const appsDir = path.join(os.homedir(), ".zennith-cloud", "apps");
        const appDir = path.join(appsDir, `app-${input.appId}`);

        const result = await processManager.restartApplication(
          input.appId,
          appDir,
          app.entryPoint
        );

        if (!result.success) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: result.error || "Failed to restart application",
          });
        }

        // Atualiza o status da aplicacao
        await db.updateApplication(input.appId, { status: "running" });

        return { success: true };
      }),

    // Obter logs
    getLogs: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .query(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        const logs = processManager.getApplicationLogs(input.appId);
        return { logs };
      }),

    // Obter estrutura de arquivos
    getFileStructure: protectedProcedure
      .input(z.object({ appId: z.number() }))
      .query(async ({ ctx, input }) => {
        const app = await db.getApplicationById(input.appId);
        if (!app || app.userId !== ctx.user.id) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        const appsDir = path.join(os.homedir(), ".zennith-cloud", "apps");
        const appDir = path.join(appsDir, `app-${input.appId}`);

        const structure = zipManager.getDirectoryStructure(appDir);
        return structure;
      }),

    // Obter status do usuario
    getUserStatus: protectedProcedure.query(async ({ ctx }) => {
      const user = await db.getUserById(ctx.user.id);
      if (!user) {
        throw new TRPCError({ code: "NOT_FOUND" });
      }

      return {
        totalRamMb: user.totalRamMb,
        usedRamMb: user.usedRamMb,
        availableRamMb: user.totalRamMb - user.usedRamMb,
        totalVcpu: user.totalVcpu,
        usedVcpu: user.usedVcpu,
        availableVcpu: user.totalVcpu - user.usedVcpu,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;
