import { storagePut } from "./storage";
import * as fs from "fs";
import * as path from "path";

/**
 * Faz upload de um arquivo para S3
 */
export async function uploadFileToS3(
  filePath: string,
  fileName: string
): Promise<{ success: boolean; url?: string; key?: string; error?: string }> {
  try {
    if (!fs.existsSync(filePath)) {
      return { success: false, error: "File not found" };
    }

    const fileContent = fs.readFileSync(filePath);
    const fileKey = `apps/${Date.now()}-${fileName}`;

    const result = await storagePut(fileKey, fileContent, "application/zip");

    return {
      success: true,
      url: result.url,
      key: result.key,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Upload failed",
    };
  }
}

/**
 * Faz download de um arquivo do S3 para um local temporário
 */
export async function downloadFileFromS3(
  url: string,
  destinationPath: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      return { success: false, error: "Failed to download file" };
    }

    const buffer = await response.arrayBuffer();
    fs.writeFileSync(destinationPath, Buffer.from(buffer));

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Download failed",
    };
  }
}
