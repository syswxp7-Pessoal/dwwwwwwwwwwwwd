import { protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import * as fs from "fs";
import * as path from "path";
import * as os from "os";

export const uploadRouter = router({
  uploadZip: protectedProcedure
    .input(
      z.object({
        fileName: z.string(),
        fileData: z.instanceof(Uint8Array),
      })
    )
    .mutation(async ({ input }) => {
      try {
        console.log(`[Upload] Starting upload for file: ${input.fileName}, size: ${input.fileData.length} bytes`);
        
        // Valida que é um arquivo ZIP
        if (!input.fileName.endsWith(".zip")) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Only ZIP files are allowed",
          });
        }
        console.log(`[Upload] File validation passed`);

        // Limita o tamanho do arquivo a 100MB
        const maxSize = 100 * 1024 * 1024;
        if (input.fileData.length > maxSize) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "File is too large. Maximum size is 100MB",
          });
        }
        console.log(`[Upload] Size validation passed`);

        // Armazena localmente para acesso rápido (sem depender de S3)
        const localZipDir = path.join(os.homedir(), ".zennith-cloud", "uploads");
        if (!fs.existsSync(localZipDir)) {
          fs.mkdirSync(localZipDir, { recursive: true });
          console.log(`[Upload] Created local directory: ${localZipDir}`);
        }
        const localZipPath = path.join(localZipDir, `${Date.now()}-${input.fileName}`);
        console.log(`[Upload] Writing file to: ${localZipPath}`);
        fs.writeFileSync(localZipPath, Buffer.from(input.fileData));
        console.log(`[Upload] File written successfully`);

        // Tenta fazer upload para S3, mas não falha se não conseguir
        let s3Result = null;
        try {
          console.log(`[Upload] Attempting S3 upload...`);
          const fileKey = `apps/${Date.now()}-${input.fileName}`;
          s3Result = await storagePut(fileKey, input.fileData, "application/zip");
          console.log(`[Upload] S3 upload successful`);
        } catch (s3Error) {
          console.warn(`[Upload] S3 upload failed (non-critical):`, s3Error instanceof Error ? s3Error.message : s3Error);
          // Continua mesmo se S3 falhar, pois temos o arquivo local
        }

        return {
          success: true,
          url: s3Result?.url || localZipPath,
          key: s3Result?.key || `local:${localZipPath}`,
          localPath: localZipPath,
        };
      } catch (error) {
        console.error(`[Upload] Error:`, error instanceof Error ? error.message : error);
        if (error instanceof TRPCError) {
          throw error;
        }
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: error instanceof Error ? error.message : "Upload failed",
        });
      }
    }),
});
