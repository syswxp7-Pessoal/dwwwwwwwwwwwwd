import * as fs from "fs";
import * as path from "path";
import * as os from "os";
import { exec } from "child_process";
import { promisify } from "util";
import AdmZip from "adm-zip";

const execAsync = promisify(exec);

/**
 * Extrai um arquivo ZIP para um diretório usando adm-zip
 */
export async function extractZip(
  zipFilePath: string,
  targetDir: string
): Promise<{ success: boolean; error?: string }> {
  try {
    console.log(`[extractZip] Starting extraction from ${zipFilePath} to ${targetDir}`);
    
    // Verifica se o arquivo ZIP existe
    if (!fs.existsSync(zipFilePath)) {
      throw new Error(`ZIP file not found: ${zipFilePath}`);
    }
    
    const fileSize = fs.statSync(zipFilePath).size;
    console.log(`[extractZip] ZIP file found, size: ${fileSize} bytes`);
    
    // Cria o diretório de destino se não existir
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
      console.log(`[extractZip] Created target directory: ${targetDir}`);
    } else {
      // Limpa o diretório se já existir
      const existingFiles = fs.readdirSync(targetDir);
      for (const file of existingFiles) {
        const filePath = path.join(targetDir, file);
        if (fs.statSync(filePath).isDirectory()) {
          fs.rmSync(filePath, { recursive: true });
        } else {
          fs.unlinkSync(filePath);
        }
      }
      console.log(`[extractZip] Cleaned existing target directory`);
    }

    // Usa adm-zip para extrair o arquivo
    console.log(`[extractZip] Reading ZIP file...`);
    const zip = new AdmZip(zipFilePath);
    
    console.log(`[extractZip] Extracting ${zip.getEntries().length} entries...`);
    zip.extractAllTo(targetDir, true);
    
    console.log(`[extractZip] Extraction completed successfully`);

    // Verifica se há arquivos no diretório de destino
    const files = fs.readdirSync(targetDir);
    console.log(`[extractZip] Extracted ${files.length} items: ${files.join(', ')}`);

    if (files.length === 0) {
      throw new Error("ZIP file appears to be empty");
    }

    return { success: true };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "Failed to extract ZIP";
    console.error(`[extractZip] Error: ${errorMsg}`);
    console.error(`[extractZip] Stack:`, error instanceof Error ? error.stack : "");
    return {
      success: false,
      error: errorMsg,
    };
  }
}

/**
 * Obtém a estrutura de diretórios de um caminho
 * Mostra apenas os arquivos do ZIP, não a pasta app-ID
 */
export function getDirectoryStructure(
  dirPath: string,
  maxDepth: number = 5,
  currentDepth: number = 0
): any {
  if (currentDepth >= maxDepth) {
    return null;
  }

  if (!fs.existsSync(dirPath)) {
    console.warn(`[getDirectoryStructure] Directory not found: ${dirPath}`);
    return null;
  }

  console.log(`[getDirectoryStructure] Reading directory: ${dirPath}`);
  const items = fs.readdirSync(dirPath);
  console.log(`[getDirectoryStructure] Found ${items.length} items: ${items.join(', ')}`);
  
  // Se estamos no primeiro nível (currentDepth === 0), retorna apenas os filhos
  // Isso evita mostrar a pasta app-ID
  if (currentDepth === 0) {
    const children: any[] = [];
    
    for (const item of items) {
      // Ignora node_modules e pastas ocultas
      if (item.startsWith(".") || item === "node_modules") {
        console.log(`[getDirectoryStructure] Skipping: ${item}`);
        continue;
      }

      const itemPath = path.join(dirPath, item);
      const stat = fs.statSync(itemPath);

      if (stat.isDirectory()) {
        const subStructure = getDirectoryStructure(itemPath, maxDepth, currentDepth + 1);
        if (subStructure) {
          children.push(subStructure);
        }
      } else {
        children.push({
          name: item,
          type: "file",
          size: stat.size,
        });
      }
    }
    
    // Retorna um objeto virtual que contém os arquivos do ZIP
    const structure: any = {
      name: "Arquivos",
      type: "directory",
      children,
    };
    
    console.log(`[getDirectoryStructure] Root structure:`, JSON.stringify(structure, null, 2).substring(0, 500));
    return structure;
  }
  
  // Para níveis mais profundos, usa a lógica normal
  const structure: any = {
    name: path.basename(dirPath),
    type: "directory",
    children: [],
  };

  for (const item of items) {
    // Ignora node_modules e pastas ocultas
    if (item.startsWith(".") || item === "node_modules") {
      console.log(`[getDirectoryStructure] Skipping: ${item}`);
      continue;
    }

    const itemPath = path.join(dirPath, item);
    const stat = fs.statSync(itemPath);

    if (stat.isDirectory()) {
      const subStructure = getDirectoryStructure(itemPath, maxDepth, currentDepth + 1);
      if (subStructure) {
        structure.children.push(subStructure);
      }
    } else {
      structure.children.push({
        name: item,
        type: "file",
        size: stat.size,
      });
    }
  }

  console.log(`[getDirectoryStructure] Structure for ${dirPath}:`, JSON.stringify(structure, null, 2).substring(0, 500));
  return structure;
}

/**
 * Lista arquivos em um diretório
 */
export function listFiles(dirPath: string): string[] {
  if (!fs.existsSync(dirPath)) {
    return [];
  }

  const files: string[] = [];

  function walkDir(currentPath: string, relativePath: string = "") {
    const items = fs.readdirSync(currentPath);

    for (const item of items) {
      // Ignora node_modules e pastas ocultas
      if (item.startsWith(".") || item === "node_modules") {
        continue;
      }

      const itemPath = path.join(currentPath, item);
      const stat = fs.statSync(itemPath);

      if (stat.isDirectory()) {
        walkDir(itemPath, path.join(relativePath, item));
      } else {
        files.push(path.join(relativePath, item));
      }
    }
  }

  walkDir(dirPath);
  return files;
}

/**
 * Obtém o conteúdo de um arquivo
 */
export function getFileContent(
  filePath: string,
  maxSize: number = 1024 * 1024
): { success: boolean; content?: string; error?: string } {
  try {
    if (!fs.existsSync(filePath)) {
      return { success: false, error: "File not found" };
    }

    const stat = fs.statSync(filePath);
    if (stat.size > maxSize) {
      return { success: false, error: "File is too large" };
    }

    const content = fs.readFileSync(filePath, "utf-8");
    return { success: true, content };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to read file",
    };
  }
}

/**
 * Instala dependências (npm ou pip)
 */
export async function installDependencies(
  workDir: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // Verifica se existe package.json (Node.js)
    if (fs.existsSync(path.join(workDir, "package.json"))) {
      console.log(`[installDependencies] Starting Node.js dependency installation in ${workDir}`);
      console.log(`[installDependencies] Files in workDir:`, fs.readdirSync(workDir));
      
      let installSuccess = false;
      let lastError: Error | null = null;

      // Tenta com npm primeiro (mais confiável)
      try {
        console.log(`[installDependencies] Attempting npm install...`);
        console.log(`[installDependencies] Working dir: ${workDir}`);
        const { stdout: npmOut, stderr: npmErr } = await execAsync("npm install 2>&1", { 
          cwd: workDir, 
          timeout: 300000,
          maxBuffer: 50 * 1024 * 1024
        });
        console.log(`[installDependencies] npm install completed successfully`);
        console.log(`[installDependencies] npm output (last 1000 chars):`, npmOut.substring(Math.max(0, npmOut.length - 1000)));
        installSuccess = true;
      } catch (npmError) {
        lastError = npmError instanceof Error ? npmError : new Error(String(npmError));
        console.error(`[installDependencies] npm install failed:`, lastError.message);
        if (npmError instanceof Error && 'stdout' in npmError) {
          console.error(`[installDependencies] npm stdout:`, (npmError as any).stdout?.substring(0, 500));
        }
        if (npmError instanceof Error && 'stderr' in npmError) {
          console.error(`[installDependencies] npm stderr:`, (npmError as any).stderr?.substring(0, 500));
        }
        console.warn(`[installDependencies] Attempting fallback with pnpm...`);
        
        try {
          const { stdout: pnpmOut, stderr: pnpmErr } = await execAsync("pnpm install --no-frozen-lockfile", { 
            cwd: workDir, 
            timeout: 300000,
            maxBuffer: 50 * 1024 * 1024
          });
          console.log(`[installDependencies] pnpm install completed`);
          console.log(`[installDependencies] pnpm output (last 500 chars):`, pnpmOut.substring(Math.max(0, pnpmOut.length - 500)));
          if (pnpmErr) console.warn(`[installDependencies] pnpm stderr:`, pnpmErr.substring(0, 500));
          installSuccess = true;
        } catch (pnpmError) {
          console.error(`[installDependencies] pnpm also failed:`, pnpmError instanceof Error ? pnpmError.message : pnpmError);
          lastError = pnpmError instanceof Error ? pnpmError : new Error(String(pnpmError));
        }
      }

      if (!installSuccess) {
        console.error(`[installDependencies] Both npm and pnpm failed. Last error:`, lastError?.message);
        return { 
          success: false, 
          error: `Failed to install dependencies: ${lastError?.message || 'Unknown error'}` 
        };
      }
      
      // Aguarda um pouco para garantir que node_modules foi criado
      console.log(`[installDependencies] Waiting for node_modules to be created...`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Verifica se node_modules foi criado
      const nodeModulesPath = path.join(workDir, "node_modules");
      console.log(`[installDependencies] Checking for node_modules at: ${nodeModulesPath}`);
      console.log(`[installDependencies] Directory exists: ${fs.existsSync(nodeModulesPath)}`);
      console.log(`[installDependencies] Contents of workDir:`, fs.readdirSync(workDir));
      
      // Se node_modules nao foi criado, cria manualmente (pode ser que nao haja dependencias)
      if (!fs.existsSync(nodeModulesPath)) {
        console.log(`[installDependencies] node_modules not found, creating empty directory...`);
        fs.mkdirSync(nodeModulesPath, { recursive: true });
      }
      
      if (fs.existsSync(nodeModulesPath)) {
        const moduleCount = fs.readdirSync(nodeModulesPath).length;
        console.log(`[installDependencies] node_modules ready with ${moduleCount} modules`);
        return { success: true };
      } else {
        console.error(`[installDependencies] Failed to create node_modules directory`);
        return { success: false, error: "Failed to create node_modules directory" };
      }
    }

    // Verifica se existe requirements.txt (Python)
    if (fs.existsSync(path.join(workDir, "requirements.txt"))) {
      console.log(`[installDependencies] Installing Python dependencies in ${workDir}`);
      const { stdout, stderr } = await execAsync("pip install -r requirements.txt", { 
        cwd: workDir, 
        timeout: 180000,
        maxBuffer: 10 * 1024 * 1024
      });
      console.log(`[installDependencies] pip install completed`);
      if (stdout) console.log(`[installDependencies] pip stdout:`, stdout.substring(0, 500));
      if (stderr) console.warn(`[installDependencies] pip stderr:`, stderr.substring(0, 500));
      return { success: true };
    }

    // Se não há dependências, retorna sucesso
    console.log(`[installDependencies] No package.json or requirements.txt found in ${workDir}`);
    return { success: true };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "Failed to install dependencies";
    console.error(`[installDependencies] Error:`, errorMsg);
    return {
      success: false,
      error: errorMsg,
    };
  }
}
