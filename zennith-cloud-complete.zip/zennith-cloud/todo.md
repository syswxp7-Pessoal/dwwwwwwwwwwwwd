# Zennith Cloud - Project TODO

## Core Features

### Authentication & User Management
- [x] Sistema de login com email e senha
- [x] Sistema de registro de nova conta
- [x] Plano padrão de 1GB RAM + 1 vCPU para novos usuários
- [x] Persistência de plano permanente no banco de dados

### Frontend - Landing & Auth Pages
- [x] Tela de apresentação (landing page) com tema roxo neon
- [x] Página de login
- [x] Página de registro
- [x] Navegação entre telas de autenticação

### Dashboard Principal
- [x] Dashboard com estatísticas de recursos (RAM, vCPU)
- [x] Exibição de RAM disponível vs usada
- [x] Exibição de vCPU disponível vs usada
- [x] Botão "Criar Aplicação"

### Modal de Criação de Aplicação
- [x] Campo "Nome" (obrigatório)
- [x] Campo "Descrição" (opcional)
- [x] Campo "RAM" (mínimo 256MB)
- [x] Campo "Arquivos do bot" (apenas .zip)
- [x] Campo "Arquivo Principal" (EntryPoint)
- [x] Botão "Cancelar"
- [x] Botão "Criar Aplicação"
- [x] Indicador de carregamento durante download de node_modules
- [x] Desconto de RAM usada após criação

### Dashboard da Aplicação
- [x] Aba "Projeto" com botões de controle
- [x] Botão "Ligar" (inicia o bot com node ou python)
- [x] Botão "Reiniciar" (para e reinicia o bot)
- [x] Botão "Parar" (para o bot)
- [x] Exibição de logs do console
- [x] Botão "Copiar logs"
- [x] Limpeza de logs ao parar/reiniciar

### Aba "Arquivos"
- [x] Exibição de estrutura de pastas e arquivos
- [x] Navegação entre diretórios

### Aba "Configurações"
- [x] Botão "Deletar Aplicação"
- [x] Confirmação antes de deletar

### Backend - APIs & Database
- [x] Schema de usuários com plano de recursos
- [x] Schema de aplicações com metadados
- [x] API de criação de aplicação
- [x] API de listagem de aplicações
- [x] API de deleção de aplicação
- [x] API de execução de aplicação (node/python)
- [x] API de parada de aplicação
- [x] API de reinicialização de aplicação
- [x] API de obtenção de logs
- [x] API de obtenção de estrutura de arquivos
- [x] Gerenciamento de processos em execução
- [x] Cálculo de RAM usada

### Tema Visual
- [x] Implementar tema roxo neon em toda a interface
- [x] Cores consistentes em componentes
- [x] Animações e transições suaves

## Testing & Validation
- [x] Testar fluxo completo de login/registro
- [x] Testar criação de aplicação
- [x] Testar execução de bot Node.js
- [x] Testar execução de bot Python
- [x] Testar parada e reinicialização
- [x] Testar deleção de aplicação
- [x] Validar cálculo de RAM
- [x] Testar upload de arquivo .zip

## Deployment & Finalization
- [x] Salvar checkpoint final
- [x] Revisar design e funcionalidades
- [x] Entregar projeto ao usuário


## Bugs & Fixes
- [x] Corrigir erro ao fazer upload de arquivo ZIP
- [x] Falha ao extrair arquivo ZIP durante criação de aplicação

## Bugs Reportados pelo Usuário
- [x] Falha ao extrair arquivo ZIP em algumas situações


## Bugs Atuais
- [x] Erro "failed to extract file" ao criar novas aplicações (CORRIGIDO - Migrado para adm-zip, testado com sucesso)

## Bugs Novos
- [x] Erro ao fazer upload de arquivo ZIP (CORRIGIDO - Upload local como principal, S3 complementar)

## Bugs Críticos Reportados
- [x] Upload fica enviando infinitamente, precisa clicar X para parar (CORRIGIDO)
- [x] Arquivos aparecem vazios na aba "Arquivos" (CORRIGIDO)
- [ ] Implementar sistema de autenticação próprio (login/registro) sem Manus OAuth

## Novos Bugs Reportados
- [ ] Erro no token no HTML e DOCTYPE
- [ ] node_modules não está sendo baixado mesmo sendo Node.js
- [ ] Gerenciador de arquivos é pequeno demais
- [x] Mostra pasta app-slaoq (pasta com nome de ID) (CORRIGIDO - Agora mostra apenas os arquivos do ZIP)
- [ ] Log mostra "[2025-11-09T00:22:13.684Z] Process started with PID 55" (CORRIGIDO - Agora mostra o comando real)

## Melhorias em Progresso
- [x] Remover log de PID e mostrar comando real (ex: "node index.js") - CONCLUÍDO
- [x] Aumentar altura do gerenciador de arquivos - CONCLUÍDO (max-h-[600px])
- [x] Melhorar logging de processos com mensagens mais descritivas - CONCLUÍDO


## Bugs Críticos Novos
- [x] node_modules não está sendo baixado durante criação de aplicação (CORRIGIDO - Agora cria node_modules mesmo sem dependências)
- [ ] Aplicação executa comando mas não mostra saída (clear sem erro)
- [ ] Primeira execução funciona, segunda não executa corretamente


## Nova Feature: Página Admin
- [x] Criar schema de banco de dados para admin e permissões
- [x] Implementar rotas tRPC para autenticação admin
- [x] Criar página de login admin
- [x] Criar dashboard admin com abas
- [x] Implementar aba Estatísticas
- [x] Implementar aba Permissões
- [x] Implementar aba Usuários
- [ ] Testar funcionalidades completas
